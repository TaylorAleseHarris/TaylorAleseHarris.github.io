I got most of my fungi information along with a couple images from https://www.homestratosphere.com/types-of-mushrooms/
and https://www.treehugger.com/colorful-fungi-mushrooms-4869722